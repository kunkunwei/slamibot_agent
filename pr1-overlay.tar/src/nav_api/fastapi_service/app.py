"""ASGI entry point for the incremental FastAPI + MCP migration."""

import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from .capture import CAPTURE_DIR
from .capture import register_mcp_tools as register_capture_tools
from .capture import router as capture_router
from .database import init_db
from .mcp_compat import MCPServer
from .models import fail
from .control import register_mcp_tools as register_control_tools
from .control import router as control_router
from .launch_api import register_mcp_tools as register_launch_tools
from .launch_api import router as launch_router
from .localization import register_mcp_tools as register_localization_tools
from .localization import router as localization_router
from .map_api import register_mcp_tools as register_map_tools
from .map_api import router as map_router
from .navigation import register_mcp_tools as register_navigation_tools
from .navigation import router as navigation_router
from .point import register_mcp_tools, router as point_router
from .ros_client import ros_client
from .status import register_mcp_tools as register_status_tools
from .status import router as status_router
from .task import register_mcp_tools as register_task_tools
from .task import router as task_router
from .voice import register_mcp_tools as register_voice_tools
from .voice import router as voice_router
from .audio import router as audio_router


mcp = MCPServer(
    "scout-navigation",
    instructions="Scout Mini 地图、点位与导航控制工具。",
)
register_mcp_tools(mcp)
register_task_tools(mcp)
register_localization_tools(mcp)
register_navigation_tools(mcp)
register_map_tools(mcp)
register_control_tools(mcp)
register_launch_tools(mcp)
register_status_tools(mcp)
register_capture_tools(mcp)
mcp_http_app = mcp.streamable_http_app()


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    init_db()
    ros_client.start()
    ros_client.start_camera_cache()
    async with mcp.session_manager.run():
        yield
    ros_client.stop()


app = FastAPI(
    title="Scout Mini Navigation API",
    description="FastAPI + MCP 渐进迁移服务。",
    version="0.1.0",
    lifespan=lifespan,
)

_cors_origins = [
    origin.strip()
    for origin in os.environ.get("NAV_API_CORS_ORIGINS", "").split(",")
    if origin.strip()
]
if _cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
        allow_headers=["*"],
        expose_headers=["Mcp-Session-Id"],
    )


@app.exception_handler(RequestValidationError)
async def validation_error_handler(
    _request, exc: RequestValidationError
) -> JSONResponse:
    fields = [".".join(str(part) for part in error["loc"][1:]) for error in exc.errors()]
    response = fail("请求参数校验失败: %s" % ", ".join(fields))
    return JSONResponse(status_code=200, content=response.model_dump())


@app.get("/health", tags=["系统"])
def health() -> dict:
    return {
        "success": True,
        "service": "nav-api-fastapi",
        "rosbridgeConnected": ros_client.is_connected,
    }


app.include_router(point_router)
app.include_router(task_router)
app.include_router(localization_router)
app.include_router(navigation_router)
app.include_router(map_router)
app.include_router(control_router)
app.include_router(launch_router)
app.include_router(status_router)
app.include_router(voice_router)
app.include_router(audio_router)
app.include_router(capture_router)

# 照片静态回读(在 MCP 兜底路由之前挂载)
os.makedirs(CAPTURE_DIR, exist_ok=True)
app.mount("/captures", StaticFiles(directory=CAPTURE_DIR), name="captures")


# Keep this last: Mount("/") is a catch-all route. The MCP endpoint is /mcp.
app.mount("/", mcp_http_app)
