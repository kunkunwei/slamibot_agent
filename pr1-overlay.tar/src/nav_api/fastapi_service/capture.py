"""点位拍照:经 rosbridge 相机帧缓存抓帧存盘,记录 Captures 表。

两种触发来源,共用同一套存盘/登记逻辑:
  - 手动:POST /api/capture/photo(App / 调试)
  - 到点自动:nav_multi_node 每到达一个点位发布 /nav_multi/point_arrived
    事件,本模块经 ros_client 注册的回调按点位 action 分发。
    目前支持 action="photo",后续新增动作类型只需在 ACTION_HANDLERS
    注册一个处理函数,nav_multi_node 与表结构都不用改。

相机 topic 经环境变量 CAMERA_TOPIC 配置(默认 /SLB_CAM_B/compressed),
未接入相机时接口降级返回 fail,不影响导航与其它模块。照片回读由调用方
(APP/云端)经 /api/capture/list + /captures 静态路由拉取,本模块不主动推送。
"""

import logging
import os
import time
from typing import Any, Optional

from fastapi import APIRouter
from pydantic import Field

from .database import get_conn
from .mcp_compat import MCPServer
from .models import ApiResponse, RequestModel, fail, ok
from .ros_client import ros_client


LOGGER = logging.getLogger(__name__)

router = APIRouter(prefix="/api/capture", tags=["点位拍照"])

CAPTURE_DIR = os.environ.get(
    "CAPTURE_DIR",
    os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "db",
        "captures",
    ),
)

# 到点事件中的 action 值 → 处理函数。新增动作类型在此注册。
ACTION_PHOTO = "photo"


class CapturePhotoRequest(RequestModel):
    pointName: Optional[str] = Field(default=None, description="关联点位名")
    taskId: Optional[int] = Field(default=None, description="触发任务 ID")
    source: str = Field(default="manual", description="manual / point_action")


def _save_record(
    frame: bytes,
    point_name: Optional[str],
    task_id: Optional[int],
    source: str,
) -> dict:
    """落盘一帧 JPEG 并登记 Captures 表,返回记录 dict。"""
    os.makedirs(CAPTURE_DIR, exist_ok=True)
    base = time.strftime("%Y%m%d_%H%M%S") + "_%03d" % (int(time.time() * 1000) % 1000)
    file_name = base + ".jpg"
    # 同一毫秒连拍时避免撞名
    index = 1
    while os.path.exists(os.path.join(CAPTURE_DIR, file_name)):
        file_name = "%s_%d.jpg" % (base, index)
        index += 1
    with open(os.path.join(CAPTURE_DIR, file_name), "wb") as fh:
        fh.write(frame)
    conn = get_conn()
    try:
        cursor = conn.execute(
            "INSERT INTO Captures (pointName, fileName, taskId, source) "
            "VALUES (?,?,?,?)",
            (point_name, file_name, task_id, source),
        )
        conn.commit()
        capture_id = cursor.lastrowid
    finally:
        conn.close()
    return {
        "id": capture_id,
        "pointName": point_name,
        "fileName": file_name,
        "taskId": task_id,
        "source": source,
        "url": "/captures/%s" % file_name,
    }


def _take_photo(
    point_name: Optional[str], task_id: Optional[int], source: str
) -> ApiResponse:
    frame = ros_client.get_latest_frame()
    if frame is None:
        return fail("未收到相机帧,请检查相机驱动与 CAMERA_TOPIC 配置")
    return ok(_save_record(frame, point_name, task_id, source))


def _handle_photo_action(event: dict) -> None:
    """到点自动拍照;失败只记日志,绝不影响导航流程。"""
    result = _take_photo(event.get("pointName"), event.get("taskId"), "point_action")
    if result.success:
        LOGGER.info(
            "point_action photo saved: point=%s file=%s",
            event.get("pointName"),
            result.data["fileName"],
        )
    else:
        LOGGER.warning(
            "point_action photo failed at point %s: %s",
            event.get("pointName"),
            result.msg,
        )


ACTION_HANDLERS = {
    ACTION_PHOTO: _handle_photo_action,
}


def on_point_arrived(event: dict[str, Any]) -> None:
    """ros_client 的到点事件回调:按点位 action 分发,无 action 则忽略。"""
    handler = ACTION_HANDLERS.get(event.get("action", ""))
    if handler is None:
        return
    handler(event)


# 注册到点事件回调(ros_client 收到 /nav_multi/point_arrived 后转发到这里)
ros_client.set_point_arrived_handler(on_point_arrived)


def register_mcp_tools(mcp: MCPServer) -> None:
    mcp.tool(name="capture_photo")(take_photo)
    mcp.tool(name="capture_list")(list_captures)


@router.post("/photo", response_model=ApiResponse)
def take_photo(req: CapturePhotoRequest) -> ApiResponse:
    """抓当前相机帧存盘并登记(手动拍照)。"""
    return _take_photo(req.pointName, req.taskId, req.source)


@router.get("/list", response_model=ApiResponse)
def list_captures(pointName: Optional[str] = None, limit: int = 50) -> ApiResponse:
    """查询拍照记录(倒序,默认 50 条)。"""
    sql = "SELECT id, pointName, fileName, taskId, source, createdTime FROM Captures"
    params: list = []
    if pointName:
        sql += " WHERE pointName = ?"
        params.append(pointName)
    sql += " ORDER BY id DESC LIMIT ?"
    params.append(limit)
    conn = get_conn()
    try:
        rows = conn.execute(sql, params).fetchall()
    finally:
        conn.close()
    data = [
        {
            "id": row[0],
            "pointName": row[1],
            "fileName": row[2],
            "taskId": row[3],
            "source": row[4],
            "createdTime": row[5],
            "url": "/captures/%s" % row[2],
        }
        for row in rows
    ]
    return ok(data)
