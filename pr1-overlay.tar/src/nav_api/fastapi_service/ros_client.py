"""ROS 1 access from Python 3.10+ through rosbridge/roslibpy."""

import base64
import logging
import os
import json
import threading
from typing import Any, Callable, Optional, Tuple

import roslibpy


LOGGER = logging.getLogger(__name__)


class RosbridgeClient:
    """Keep a rosbridge connection and cache the latest AMCL pose."""

    def __init__(self) -> None:
        self._ros = roslibpy.Ros(
            host=os.environ.get("ROSBRIDGE_HOST", "127.0.0.1"),
            port=int(os.environ.get("ROSBRIDGE_PORT", "19090")),
        )
        self._pose_topic: Optional[roslibpy.Topic] = None
        self._topics: list[roslibpy.Topic] = []
        self._transport_running = False
        self._latest_pose: Optional[dict[str, float]] = None
        self._latest_nav_status: dict[str, Any] = {}
        self._latest_scout_status: Optional[dict[str, Any]] = None
        self._latest_bms_status: Optional[dict[str, Any]] = None
        self._latest_battery: Optional[dict[str, Any]] = None
        self._latest_frame: Optional[bytes] = None
        self._point_arrived_handler: Optional[Callable[[dict], None]] = None
        self._lock = threading.Lock()

    @property
    def is_connected(self) -> bool:
        return bool(self._ros.is_connected)

    def start(self) -> None:
        """Connect without preventing HTTP startup when ROS is unavailable."""
        try:
            self._ros.run(timeout=3)
            self._transport_running = True
        except Exception as exc:
            LOGGER.warning("rosbridge unavailable; ROS endpoints start degraded: %s", exc)
            self._ros.terminate()
            return

        self._pose_topic = roslibpy.Topic(
            self._ros,
            "/amcl_pose",
            "geometry_msgs/PoseWithCovarianceStamped",
        )
        self._pose_topic.subscribe(self._on_pose)
        self._topics = [
            self._pose_topic,
            self._subscribe(
                "/nav_multi/status", "std_msgs/String", self._on_nav_status
            ),
            self._subscribe(
                "/scout_status", "scout_msgs/ScoutStatus", self._on_scout_status
            ),
            self._subscribe(
                "/BMS_status", "scout_msgs/ScoutBmsStatus", self._on_bms_status
            ),
            self._subscribe(
                "/battery", "sensor_msgs/BatteryState", self._on_battery
            ),
            self._subscribe(
                "/nav_multi/point_arrived", "std_msgs/String", self._on_point_arrived
            ),
        ]
        LOGGER.info("connected to rosbridge")

    def stop(self) -> None:
        for topic in self._topics:
            topic.unsubscribe()
        if self._transport_running:
            self._ros.terminate()
            self._transport_running = False

    def _on_pose(self, message: dict[str, Any]) -> None:
        pose = message["pose"]["pose"]
        position = pose["position"]
        orientation = pose["orientation"]
        value = {
            "positionX": float(position["x"]),
            "positionY": float(position["y"]),
            "positionZ": float(position["z"]),
            "orientationX": float(orientation["x"]),
            "orientationY": float(orientation["y"]),
            "orientationZ": float(orientation["z"]),
            "orientationW": float(orientation["w"]),
        }
        with self._lock:
            self._latest_pose = value

    def _subscribe(self, name: str, message_type: str, callback) -> roslibpy.Topic:
        topic = roslibpy.Topic(self._ros, name, message_type)
        topic.subscribe(callback)
        return topic

    def _on_nav_status(self, message: dict[str, Any]) -> None:
        try:
            value = json.loads(message["data"])
        except (KeyError, TypeError, ValueError):
            return
        with self._lock:
            self._latest_nav_status = value

    def _on_scout_status(self, message: dict[str, Any]) -> None:
        with self._lock:
            self._latest_scout_status = message

    def _on_bms_status(self, message: dict[str, Any]) -> None:
        with self._lock:
            self._latest_bms_status = message

    def _on_battery(self, message: dict[str, Any]) -> None:
        with self._lock:
            self._latest_battery = message

    def _on_frame(self, message: dict[str, Any]) -> None:
        data = message.get("data")
        if isinstance(data, str):
            data = base64.b64decode(data)
        with self._lock:
            self._latest_frame = data

    def _on_point_arrived(self, message: dict[str, Any]) -> None:
        try:
            event = json.loads(message["data"])
        except (KeyError, TypeError, ValueError):
            return
        handler = self._point_arrived_handler
        if handler is None:
            return
        try:
            handler(event)
        except Exception:
            LOGGER.exception("point_arrived handler failed: %s", event)

    def set_point_arrived_handler(self, handler: Callable[[dict], None]) -> None:
        """注册到点事件回调(nav_multi_node 每到达一个点位发布一次)。"""
        self._point_arrived_handler = handler

    def get_current_pose(self) -> Tuple[Optional[dict[str, float]], str]:
        if not self.is_connected:
            return None, "rosbridge 未连接"
        with self._lock:
            pose = dict(self._latest_pose) if self._latest_pose else None
        if pose is None:
            return None, "尚未收到 /amcl_pose"
        return pose, "success"

    def _call_service(
        self, name: str, service_type: str, values: Optional[dict] = None
    ) -> Tuple[bool, str]:
        if not self.is_connected:
            return False, "rosbridge 未连接"
        try:
            service = roslibpy.Service(self._ros, name, service_type)
            result = service.call(roslibpy.ServiceRequest(values or {}), timeout=3)
            if "success" in result:
                return bool(result["success"]), result.get("message", "")
            return True, "success"
        except Exception as exc:
            return False, "ROS service 调用失败: %s" % exc

    def set_initial_pose(
        self,
        x: float,
        y: float,
        z: float,
        qx: float,
        qy: float,
        qz: float,
        qw: float,
    ) -> Tuple[bool, str]:
        if not self.is_connected:
            return False, "rosbridge 未连接"
        topic = roslibpy.Topic(
            self._ros, "/initialpose", "geometry_msgs/PoseWithCovarianceStamped"
        )
        message = {
            "header": {"frame_id": "map"},
            "pose": {
                "pose": {
                    "position": {"x": x, "y": y, "z": z},
                    "orientation": {"x": qx, "y": qy, "z": qz, "w": qw},
                },
                "covariance": [
                    0.25, 0, 0, 0, 0, 0,
                    0, 0.25, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0.068,
                ],
            },
        }
        try:
            topic.publish(roslibpy.Message(message))
            return True, "设置初始位姿成功"
        except Exception as exc:
            return False, "发布初始位姿失败: %s" % exc

    def trigger_global_localization(self) -> Tuple[bool, str]:
        success, message = self._call_service(
            "/global_localization", "std_srvs/Empty"
        )
        if success:
            message = "重定位已触发,请移动机器人使粒子收敛"
        return success, message

    def start_nav_task(
        self, task_id: int, task_name: str, points: list[dict]
    ) -> Tuple[bool, str]:
        payload = json.dumps(
            {"taskId": task_id, "taskName": task_name, "points": points},
            ensure_ascii=False,
        )
        return self._call_service(
            "/nav_multi/execute", "nav_api/NavCommand", {"data": payload}
        )

    def pause_nav(self) -> Tuple[bool, str]:
        return self._call_service("/nav_multi/pause", "std_srvs/Trigger")

    def resume_nav(self) -> Tuple[bool, str]:
        return self._call_service("/nav_multi/resume", "std_srvs/Trigger")

    def cancel_nav(self) -> Tuple[bool, str]:
        return self._call_service("/nav_multi/cancel", "std_srvs/Trigger")

    def get_nav_status(self) -> dict[str, Any]:
        with self._lock:
            value = dict(self._latest_nav_status)
        return value or {
            "state": "IDLE",
            "taskId": None,
            "taskName": "",
            "currentPointIndex": 0,
            "totalPoints": 0,
            "currentPointName": "",
            "error": "",
        }

    def get_chassis_status(self) -> dict[str, Any]:
        with self._lock:
            scout = dict(self._latest_scout_status or {})
            bms = dict(self._latest_bms_status or {})
        return {
            "velocity": {
                "linear": scout.get("linear_velocity"),
                "angular": scout.get("angular_velocity"),
                "lateral": scout.get("lateral_velocity"),
            },
            "battery": {
                "soc": bms.get("SOC"),
                "soh": bms.get("SOH"),
                "voltage": bms.get("battery_voltage"),
                "current": bms.get("battery_current"),
                "temperature": bms.get("battery_temperature"),
            },
            "chassis": {
                "baseState": scout.get("base_state"),
                "controlMode": scout.get("control_mode"),
                "faultCode": scout.get("fault_code"),
            },
        }

    def get_battery_state(self) -> dict[str, float]:
        with self._lock:
            battery = dict(self._latest_battery or {})
        percentage = battery.get("percentage") or 0
        return {
            "percent": float(percentage) * 100.0,
            "voltage": float(battery.get("voltage") or 0),
        }

    def start_camera_cache(self) -> None:
        """订阅压缩图像 topic 并缓存最新一帧(拍照用)。

        topic 名经环境变量 CAMERA_TOPIC 配置,默认取 OAK 驱动的中央相机;
        未接入相机时不会抛错,拍照接口降级返回 fail。
        """
        if not self.is_connected:
            return
        topic_name = os.environ.get("CAMERA_TOPIC", "/SLB_CAM_B/compressed")
        topic = self._subscribe(
            topic_name, "sensor_msgs/CompressedImage", self._on_frame
        )
        self._topics.append(topic)
        LOGGER.info("camera frame cache started on %s", topic_name)

    def get_latest_frame(self) -> Optional[bytes]:
        with self._lock:
            return self._latest_frame


ros_client = RosbridgeClient()
