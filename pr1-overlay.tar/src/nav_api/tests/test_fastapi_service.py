"""Regression tests for the incremental FastAPI + MCP service."""

import asyncio

from fastapi.testclient import TestClient

from fastapi_service import database
from fastapi_service import process_manager
from fastapi_service.app import app, mcp
from fastapi_service.ros_client import ros_client


def _seed_map() -> None:
    with database.get_conn() as conn:
        conn.execute(
            "INSERT INTO Map (mapName, mapDisplayName, isActive) VALUES (?,?,?)",
            ("test_map", "测试地图", 1),
        )


def _client(tmp_path, monkeypatch) -> TestClient:
    monkeypatch.setattr(database, "DB_PATH", str(tmp_path / "nav_api.db"))
    monkeypatch.setattr(ros_client, "start", lambda: None)
    monkeypatch.setattr(ros_client, "stop", lambda: None)
    database.init_db()
    _seed_map()
    return TestClient(app)


def _point_payload(name: str = "点位 A") -> dict:
    return {
        "type": 2,
        "mapName": "test_map",
        "pointName": name,
        "positionX": 1.0,
        "positionY": 2.0,
        "positionZ": 0.0,
        "orientationX": 0.0,
        "orientationY": 0.0,
        "orientationZ": 0.0,
        "orientationW": 1.0,
    }


def test_openapi_and_point_crud(tmp_path, monkeypatch) -> None:
    with _client(tmp_path, monkeypatch) as client:
        assert client.get("/health").status_code == 200
        schema = client.get("/openapi.json").json()
        assert "/api/map/point/add" in schema["paths"]
        assert "/api/map/nav_multi/execute" in schema["paths"]
        assert "/api/map/maps/delete" in schema["paths"]
        assert "/api/status/" in schema["paths"]

        created = client.post("/api/map/point/add", json=_point_payload()).json()
        assert created["success"] is True
        point_id = created["data"]["id"]

        listed = client.get(
            "/api/map/point/list", params={"mapName": "test_map"}
        ).json()
        assert listed["data"][0]["pointName"] == "点位 A"

        updated = client.post(
            "/api/map/point/update",
            json={"id": point_id, "pointName": "点位 B"},
        ).json()
        assert updated["success"] is True

        deleted = client.get(
            "/api/map/point/delete",
            params={"id": point_id, "force": "true"},
        ).json()
        assert deleted["success"] is True


def test_task_crud_and_navigation(tmp_path, monkeypatch) -> None:
    client = _client(tmp_path, monkeypatch)
    point = client.post("/api/map/point/add", json=_point_payload()).json()
    point_id = point["data"]["id"]

    task = client.post(
        "/api/map/task/save",
        json={
            "taskName": "巡检任务",
            "mapName": "test_map",
            "points": [{"pointId": point_id, "pointName": "点位 A"}],
        },
    ).json()
    assert task["success"] is True
    task_id = task["data"]["taskId"]

    listed = client.get(
        "/api/map/task/list", params={"mapName": "test_map"}
    ).json()
    assert listed["data"][0]["points"][0]["valid"] is True

    captured = {}

    def start_nav_task(task_id, task_name, points):
        captured.update(task_id=task_id, task_name=task_name, points=points)
        return True, "started"

    monkeypatch.setattr(ros_client, "start_nav_task", start_nav_task)
    executed = client.post(
        "/api/map/nav_multi/execute", json={"taskId": task_id}
    ).json()
    assert executed["success"] is True
    assert captured["points"][0]["pointName"] == "点位 A"

    deleted = client.get(
        "/api/map/task/delete", params={"id": task_id}
    ).json()
    assert deleted["success"] is True


def test_map_status_and_process_routes(tmp_path, monkeypatch) -> None:
    client = _client(tmp_path, monkeypatch)
    fake_status = {
        "current_mode": "idle",
        "base_running": False,
        "mapping_running": False,
        "navigation_running": False,
        "pcd_running": False,
    }
    monkeypatch.setattr(process_manager, "get_status", lambda: fake_status)
    monkeypatch.setattr(
        process_manager, "start_mapping", lambda: (False, "base not running")
    )

    maps = client.get("/api/map/maps/list").json()
    assert maps["data"][0]["mapName"] == "test_map"

    launch = client.get("/api/launch/status").json()
    assert launch["data"]["current_mode"] == "idle"

    mapping = client.post("/api/launch/mapping/start").json()
    assert mapping["success"] is False

    status = client.get("/api/status/").json()
    assert status["success"] is True
    assert status["data"]["mapName"] == "test_map"


def test_validation_keeps_legacy_envelope(tmp_path, monkeypatch) -> None:
    # No lifespan is needed for FastAPI's validation path. MCP SDK session
    # managers intentionally permit one process lifecycle only.
    client = _client(tmp_path, monkeypatch)
    response = client.post("/api/map/point/add", json={"pointName": "缺字段"})
    assert response.status_code == 200
    assert response.json()["success"] is False


def test_mcp_tools_use_the_same_request_models(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr(database, "DB_PATH", str(tmp_path / "mcp.db"))
    database.init_db()
    _seed_map()

    async def get_tools():
        return await mcp.list_tools()

    tools = {tool.name: tool for tool in asyncio.run(get_tools())}
    assert len(tools) == 37
    assert "point_add" in tools
    assert "capture_photo" in tools
    assert "capture_list" in tools
    assert "execute_navigation_task" in tools
    assert "get_robot_status" in tools
    request_schema = tools["point_add"].inputSchema["properties"]["request"]
    assert "$ref" in request_schema
    assert "PointCreateRequest" in tools["point_add"].inputSchema["$defs"]

    async def call_tool():
        return await mcp.call_tool(
            "point_add", {"request": _point_payload("MCP 点位")}
        )

    result = asyncio.run(call_tool())
    assert result


def test_voice_parse_intent() -> None:
    from fastapi_service import voice

    # Dog action: returns type, keyword, action
    intent = voice.parse_intent("打招呼", "ring_mic", 30.0)
    assert intent["type"] == "dog_action"
    assert intent["keyword"] == "打招呼"
    assert intent["action"] == "hello"

    intent = voice.parse_intent("蹲下", "app_mic", None)
    assert intent["type"] == "dog_action"
    assert intent["action"] == "crouch"

    # Start mapping
    intent = voice.parse_intent("开始建图", "app_mic", None)
    assert intent["type"] == "start_mapping"
    assert intent["keyword"] == "开始建图"

    # Save mapping
    intent = voice.parse_intent("建图完毕", "app_mic", None)
    assert intent["type"] == "save_mapping"

    # Mark point
    intent = voice.parse_intent("标记目标点1", "app_mic", None)
    assert intent["type"] == "mark_point"

    # Nav goal: prefix matching extracts point name
    intent = voice.parse_intent("导航到图书馆", "app_mic", None)
    assert intent["type"] == "nav_goal"
    assert intent["pointName"] == "图书馆"
    assert intent["keyword"] == "导航到"

    # Come to me
    intent = voice.parse_intent("到我跟前来", "ring_mic", 45.0)
    assert intent["type"] == "come_to_me"

    # Unknown
    assert voice.parse_intent("今天天气怎么样", "app_mic", None)["type"] == "unknown"


def test_voice_intent_endpoint(tmp_path, monkeypatch) -> None:
    from fastapi_service import voice

    # Skip dog module tests since it's not available yet
    # Just test that intent parsing works without dispatch

    with _client(tmp_path, monkeypatch) as client:
        # Dog action: parsed but dispatch fails (dog module unavailable)
        resp = client.post("/api/voice/intent", json={"text": "蹲下"}).json()
        assert resp["data"]["intent"]["type"] == "dog_action"
        assert resp["data"]["dispatched"] is False  # dog module not available

        # Unknown command
        resp = client.post("/api/voice/intent", json={"text": "随便聊聊"}).json()
        assert resp["success"] is False

        # Come to me: parsed but not dispatched (Phase 0)
        resp = client.post(
            "/api/voice/intent",
            json={"text": "到我跟前来", "source": "ring_mic", "bearingDeg": 10.0},
        ).json()
        assert resp["data"]["intent"]["type"] == "come_to_me"
        assert resp["data"]["dispatched"] is False


def test_ros_client_camera_frame_cache() -> None:
    import base64

    client = ros_client.__class__()

    # 初始为空;注入一帧(base64 与 bytes 两种形态)后可取
    assert client.get_latest_frame() is None
    client._on_frame({"format": "jpeg", "data": b"\xff\xd8\xff"})
    assert client.get_latest_frame() == b"\xff\xd8\xff"

    client._on_frame(
        {"format": "jpeg", "data": base64.b64encode(b"\xff\xd8\xfe").decode()}
    )
    assert client.get_latest_frame() == b"\xff\xd8\xfe"


def test_ros_client_point_arrived_event() -> None:
    import json

    client = ros_client.__class__()
    received = []
    client.set_point_arrived_handler(received.append)

    client._on_point_arrived(
        {"data": json.dumps({"pointName": "A", "action": "photo"})}
    )
    assert received == [{"pointName": "A", "action": "photo"}]

    # 坏 JSON / 无 handler 都不应抛错
    client._on_point_arrived({"data": "not-json"})
    client._on_point_arrived({})
    assert len(received) == 1
    client.set_point_arrived_handler(None)
    client._on_point_arrived({"data": json.dumps({"pointName": "B"})})
    assert len(received) == 1


def _patch_capture_dir(tmp_path, monkeypatch):
    from fastapi_service import capture

    capture_dir = tmp_path / "captures"
    monkeypatch.setattr(capture, "CAPTURE_DIR", str(capture_dir))
    # /captures 静态路由在 app 导入时已挂载,同步改其目录保证回读指向临时目录
    for route in app.routes:
        if getattr(route, "name", None) == "captures":
            route.app.directory = str(capture_dir)
            route.app.all_directories = [str(capture_dir)]
    return capture


def test_capture_photo_and_list(tmp_path, monkeypatch) -> None:
    capture = _patch_capture_dir(tmp_path, monkeypatch)
    monkeypatch.setattr(
        capture.ros_client, "get_latest_frame", lambda: b"\xff\xd8\xff\xe0jpeg"
    )

    client = _client(tmp_path, monkeypatch)
    resp = client.post(
        "/api/capture/photo", json={"pointName": "点位 A"}
    ).json()
    assert resp["success"] is True
    record = resp["data"]
    assert record["pointName"] == "点位 A"
    assert record["source"] == "manual"
    assert record["fileName"].endswith(".jpg")

    # 文件落盘且静态路由可读
    static = client.get("/captures/%s" % record["fileName"])
    assert static.status_code == 200
    assert static.content == b"\xff\xd8\xff\xe0jpeg"

    listed = client.get("/api/capture/list").json()
    assert listed["success"] is True
    assert listed["data"][0]["fileName"] == record["fileName"]

    # 无帧时返回 fail
    monkeypatch.setattr(capture.ros_client, "get_latest_frame", lambda: None)
    empty = client.post("/api/capture/photo", json={}).json()
    assert empty["success"] is False


def test_point_arrived_action_dispatch(tmp_path, monkeypatch) -> None:
    capture = _patch_capture_dir(tmp_path, monkeypatch)
    monkeypatch.setattr(
        capture.ros_client, "get_latest_frame", lambda: b"\xff\xd8jpeg"
    )

    client = _client(tmp_path, monkeypatch)
    # action=photo 触发自动拍照
    capture.on_point_arrived(
        {"taskId": 9, "pointName": "灭火器点", "action": "photo"}
    )
    listed = client.get("/api/capture/list").json()
    assert len(listed["data"]) == 1
    assert listed["data"][0]["source"] == "point_action"
    assert listed["data"][0]["pointName"] == "灭火器点"
    assert listed["data"][0]["taskId"] == 9

    # 无 action / 未知 action 不触发
    capture.on_point_arrived({"pointName": "路过点", "action": ""})
    capture.on_point_arrived({"pointName": "未知点", "action": "script"})
    listed = client.get("/api/capture/list").json()
    assert len(listed["data"]) == 1

    # 无帧时不崩溃、不落记录
    monkeypatch.setattr(capture.ros_client, "get_latest_frame", lambda: None)
    capture.on_point_arrived({"pointName": "无帧点", "action": "photo"})
    listed = client.get("/api/capture/list").json()
    assert len(listed["data"]) == 1


def test_nav_execute_passes_action(tmp_path, monkeypatch) -> None:
    client = _client(tmp_path, monkeypatch)
    payload = _point_payload()
    payload["action"] = "photo"
    point = client.post("/api/map/point/add", json=payload).json()
    point_id = point["data"]["id"]

    task = client.post(
        "/api/map/task/save",
        json={
            "taskName": "拍照巡检",
            "mapName": "test_map",
            "points": [{"pointId": point_id, "pointName": "点位 A"}],
        },
    ).json()
    task_id = task["data"]["taskId"]

    captured = {}

    def start_nav_task(task_id, task_name, points):
        captured.update(points=points)
        return True, "started"

    monkeypatch.setattr(ros_client, "start_nav_task", start_nav_task)
    executed = client.post(
        "/api/map/nav_multi/execute", json={"taskId": task_id}
    ).json()
    assert executed["success"] is True
    assert captured["points"][0]["action"] == "photo"