import * as ROSLIB from 'roslib';

type RosFactory = (url: string) => ROSLIB.Ros;
type StatusCb = (connected: boolean) => void;
interface Sub {
  name: string;
  type: string;
  cb: (m: unknown) => void;
  topic?: ROSLIB.Topic;
  compression?: string;
}

const defaultFactory: RosFactory = (url) => new ROSLIB.Ros({ url });

export class RosClient {
  private ros: ROSLIB.Ros | null = null;
  private connected = false;
  private statusCbs: StatusCb[] = [];
  private subs = new Set<Sub>();
  private retry = 0;
  private url: string;
  private factory: RosFactory;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private shouldReconnect = false;

  constructor(url: string, factory: RosFactory = defaultFactory) {
    this.url = url;
    this.factory = factory;
  }

  on(_ev: 'status', cb: StatusCb) {
    this.statusCbs.push(cb);
    return () => {
      this.statusCbs = this.statusCbs.filter((c) => c !== cb);
    };
  }

  private setStatus(s: boolean) {
    this.connected = s;
    this.statusCbs.forEach((c) => c(s));
  }

  connect() {
    if (this.ros) return;
    this.shouldReconnect = true;
    const ros = this.factory(this.url);
    this.ros = ros;
    ros.on('connection', () => {
      this.retry = 0;
      this.setStatus(true);
      this.subs.forEach((s) => this.attach(s));
    });
    ros.on('error', () => this.setStatus(false));
    ros.on('close', () => {
      this.ros = null;
      this.setStatus(false);
      this.subs.forEach((s) => {
        s.topic = undefined;
      });
      if (!this.shouldReconnect) return;
      const delay = Math.min(1000 * 2 ** this.retry++, 15000);
      this.reconnectTimer = setTimeout(() => this.connect(), delay);
    });
  }

  setUrl(url: string) {
    if (url === this.url) return;
    const reconnect = this.shouldReconnect;
    this.disconnect();
    this.url = url;
    if (reconnect) this.connect();
  }

  disconnect() {
    this.shouldReconnect = false;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = null;
    this.subs.forEach((s) => {
      s.topic?.unsubscribe();
      s.topic = undefined;
    });
    const ros = this.ros;
    this.ros = null;
    ros?.close();
    this.setStatus(false);
  }

  private attach(s: Sub) {
    if (!this.ros) return;
    const topic = new ROSLIB.Topic({
      ros: this.ros,
      name: s.name,
      messageType: s.type,
      compression: s.compression,
    });
    topic.subscribe((m: unknown) => s.cb(m));
    s.topic = topic;
  }

  subscribe<T = unknown>(name: string, type: string, cb: (msg: T) => void, compression?: string) {
    const s: Sub = { name, type, cb: (m) => cb(m as T), compression };
    this.subs.add(s);
    if (this.connected) this.attach(s);
    return () => {
      s.topic?.unsubscribe();
      this.subs.delete(s);
    };
  }

  /** @returns false when rosbridge is disconnected (no throw — callers may fire on timers) */
  publish(name: string, type: string, message: Record<string, unknown>): boolean {
    if (!this.ros || !this.connected) return false;
    const topic = new ROSLIB.Topic({ ros: this.ros, name, messageType: type });
    topic.publish(message);
    return true;
  }

  get isConnected() {
    return this.connected;
  }
}

export const rosClient = new RosClient('ws://127.0.0.1:19090');
