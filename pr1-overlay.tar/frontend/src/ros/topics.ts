export const TOPICS = {
  cmdVelWeb: { name: '/cmd_vel_web', type: 'geometry_msgs/Twist' },
  goalPoint3d: { name: '/goal_point_3d', type: 'geometry_msgs/PoseStamped' },
  odom: { name: '/odom', type: 'nav_msgs/Odometry' },
  slamOdom: { name: '/slam_odom', type: 'nav_msgs/Odometry' },
  robotMapPose: { name: '/robot_map_pose', type: 'geometry_msgs/PoseStamped' },
  // bodyCloud: { name: '/livox/lidar', type: 'sensor_msgs/PointCloud2' },
  globalCloud: { name: '/global_cloud', type: 'sensor_msgs/PointCloud2' },
  /** Live map cloud used by old rviz.js; /map_cloud is often empty (width=0). */
  mapCloud: { name: '/global_cloud_navigation', type: 'sensor_msgs/PointCloud2' },
  /** Legacy empty/processor topic — kept for diagnostics only */
  mapCloudRaw: { name: '/map_cloud', type: 'sensor_msgs/PointCloud2' },
  path: { name: '/path', type: 'nav_msgs/Path' },
  globalPathNav: { name: '/global_path_navigation', type: 'nav_msgs/Path' },
  pathPoint: { name: '/path_point', type: 'visualization_msgs/MarkerArray' },
  navStatus: { name: '/nav_status', type: 'std_msgs/String' },
  navMultiStatus: { name: '/nav_multi/status', type: 'std_msgs/String' },
  battery: { name: '/battery', type: 'sensor_msgs/BatteryState' },
  prohibitionAreas: { name: '/prohibition_areas', type: 'std_msgs/String' },
  planeOccMap: { name: '/map', type: 'nav_msgs/OccupancyGrid' },
} as const;
