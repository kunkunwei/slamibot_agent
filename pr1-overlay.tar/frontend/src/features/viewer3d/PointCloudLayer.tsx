import { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { usePointCloud } from './hooks/usePointCloud';
import { resolvePointsMaterialProps } from './pointCloudMaterial';

interface Props { topic: string; color?: string; maxPoints?: number; size?: number; compression?: string; }

export function PointCloudLayer({ topic, color, maxPoints = 100_000, size, compression }: Props) {
  const points = usePointCloud(topic, maxPoints, compression);
  const geomRef = useRef<THREE.BufferGeometry>(null!);
  const mat = resolvePointsMaterialProps(color);

  useEffect(() => {
    if (!points || !geomRef.current) return;
    geomRef.current.setAttribute('position', new THREE.BufferAttribute(points, 3));
    geomRef.current.computeBoundingSphere();
  }, [points]);

  if (!points || points.length === 0) return null;

  return (
    <points>
      <bufferGeometry ref={geomRef} />
      <pointsMaterial
        size={size ?? mat.size}
        vertexColors={mat.vertexColors}
        color={mat.color}
        sizeAttenuation={mat.sizeAttenuation}
        transparent
        opacity={0.95}
        depthWrite={false}
      />
    </points>
  );
}
