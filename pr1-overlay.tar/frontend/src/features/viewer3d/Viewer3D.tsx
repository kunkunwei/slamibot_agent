import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { MOUSE, TOUCH } from 'three';
import { PointCloudLayer } from './PointCloudLayer';
import { RobotMarker } from './RobotMarker';
import { PathLine } from './PathLine';
import { PathPointLayer } from './PathPointLayer';
import { MapPointMarkers } from './MapPointMarkers';
import { GoalPickMode } from './GoalPickMode';
import { useViewer3DEvents } from './hooks/useViewer3DEvents';
import { TOPICS } from '../../ros/topics';
import { useRobotStore } from '../../store/robotStore';

export function Viewer3D() {
  const { pickMode, setPickMode, visibility } = useViewer3DEvents();
  // Remount map cloud when map switches so latched /global_cloud_navigation is resubscribed.
  const mapName = useRobotStore((s) => s.status?.mapName ?? '');
  // 在点选目标/位姿/点位时禁用相机控制,避免拖方向的同时相机跟着转。
  const isPicking = pickMode === 'nav' || pickMode === 'point' || pickMode === 'pose';
  return (
    <Canvas
      style={{ background: '#0a0a0a', width: '100%', height: '100%' }}
      camera={{ position: [0, 0, 15], up: [0, 0, 1], fov: 60 }}
    >
      <ambientLight intensity={0.5} />
      <OrbitControls
        enabled={!isPicking}
        enableZoom
        enableRotate
        enablePan
        enableDamping
        dampingFactor={0.05}
        screenSpacePanning={false}
        minDistance={1}
        maxDistance={500}
        rotateSpeed={0.8}
        zoomSpeed={0.8}
        panSpeed={0.8}
        mouseButtons={{
          LEFT: MOUSE.ROTATE,
          MIDDLE: MOUSE.PAN,
          RIGHT: MOUSE.DOLLY,
        }}
        touches={{ ONE: TOUCH.ROTATE, TWO: TOUCH.DOLLY_PAN }}
      />
      {visibility.cloud && (
        <PointCloudLayer
          key={`map-cloud-${mapName}`}
          topic={TOPICS.mapCloud.name}
          color="#9ec9ff"
          size={0.1}
          maxPoints={300_000}
          compression="cbor"
        />
      )}
      {/* {visibility.cloud && (
        <PointCloudLayer topic={TOPICS.bodyCloud.name} color="#00ff88" size={0.12} maxPoints={20_000} />
      )} */}
      <RobotMarker />
      {visibility.point && <MapPointMarkers visible={visibility.point} />}
      {visibility.path && <PathLine topic={TOPICS.globalPathNav.name} />}
      {visibility.point && <PathPointLayer />}
      {(pickMode === 'nav' || pickMode === 'point' || pickMode === 'pose') && (
        <GoalPickMode mode={pickMode ?? 'nav'} onPick={() => setPickMode(null)} />
      )}
    </Canvas>
  );
}
