import { describe, it, expect, vi, beforeEach } from 'vitest';
import React from 'react';

const pointCloudTopics: string[] = [];
let lastGoalPickMode: { mode?: string } | null = null;
let lastOrbitProps: Record<string, unknown> | null = null;
let mockPickMode: 'nav' | 'point' | 'pose' | 'area' | null = null;
let mockVisibility = { path: true, cloud: true, map: true, point: true, area: true };
let pathPointRendered = false;
let mapPointsRendered = false;

vi.mock('@react-three/fiber', () => ({
  Canvas: ({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) =>
    <div data-testid="r3f-canvas" style={style}>{children}</div>,
  useFrame: vi.fn(),
  useThree: vi.fn(() => ({ camera: {}, raycaster: { setFromCamera: vi.fn(), ray: { intersectPlane: vi.fn() } } })),
}));
vi.mock('@react-three/drei', () => ({
  OrbitControls: (props: Record<string, unknown>) => {
    lastOrbitProps = props;
    return null;
  },
  Line: () => null,
  Html: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));
vi.mock('../PointCloudLayer', () => ({
  PointCloudLayer: ({ topic }: { topic: string }) => {
    pointCloudTopics.push(topic);
    return <div data-testid={`pc-${topic}`} />;
  },
}));
vi.mock('../RobotMarker', () => ({ RobotMarker: () => null }));
vi.mock('../PathLine', () => ({ PathLine: () => null }));
vi.mock('../PathPointLayer', () => ({
  PathPointLayer: () => {
    pathPointRendered = true;
    return <div data-testid="path-point-layer" />;
  },
}));
vi.mock('../MapPointMarkers', () => ({
  MapPointMarkers: ({ visible }: { visible?: boolean }) => {
    mapPointsRendered = visible ?? false;
    return <div data-testid="map-point-markers" />;
  },
}));
vi.mock('../GoalPickMode', () => ({
  GoalPickMode: ({ mode }: { mode?: string }) => {
    lastGoalPickMode = { mode };
    return <div data-testid={`goal-pick-${mode ?? 'nav'}`} />;
  },
}));
vi.mock('../hooks/useViewer3DEvents', () => ({
  useViewer3DEvents: () => ({
    pickMode: mockPickMode,
    setPickMode: vi.fn(),
    followMode: false,
    visibility: mockVisibility,
  }),
}));
vi.mock('../../../store/robotStore', () => ({
  useRobotStore: (sel: (s: { status: { mapName: string } | null }) => unknown) =>
    sel({ status: { mapName: 'office room' } }),
}));

import { render, screen } from '@testing-library/react';
import { Viewer3D } from '../Viewer3D';
import { MOUSE } from 'three';

describe('Viewer3D', () => {
  beforeEach(() => {
    pointCloudTopics.length = 0;
    lastGoalPickMode = null;
    lastOrbitProps = null;
    pathPointRendered = false;
    mapPointsRendered = false;
    mockPickMode = null;
    mockVisibility = { path: true, cloud: true, map: true, point: true, area: true };
  });

  it('renders canvas container', () => {
    render(<Viewer3D />);
    expect(screen.getByTestId('r3f-canvas')).toBeInTheDocument();
  });

  it('subscribes map layer to /global_cloud_navigation (not empty /map_cloud)', () => {
    render(<Viewer3D />);
    expect(pointCloudTopics).toContain('/global_cloud_navigation');
    // expect(pointCloudTopics).toContain('/livox/lidar');
    expect(pointCloudTopics).not.toContain('/map_cloud');
  });

  it('activates GoalPickMode in point mode for 标记位点', () => {
    mockPickMode = 'point';
    render(<Viewer3D />);
    expect(screen.getByTestId('goal-pick-point')).toBeInTheDocument();
    expect(lastGoalPickMode?.mode).toBe('point');
  });

  it('activates GoalPickMode in pose mode for 设置位姿', () => {
    mockPickMode = 'pose';
    render(<Viewer3D />);
    expect(screen.getByTestId('goal-pick-pose')).toBeInTheDocument();
    expect(lastGoalPickMode?.mode).toBe('pose');
  });

  it('maps middle mouse button to pan', () => {
    render(<Viewer3D />);
    const buttons = lastOrbitProps?.mouseButtons as { MIDDLE?: number } | undefined;
    expect(buttons?.MIDDLE).toBe(MOUSE.PAN);
  });

  it('disables OrbitControls while picking so drag sets goal instead of rotating camera', () => {
    mockPickMode = 'nav';
    render(<Viewer3D />);
    expect(lastOrbitProps?.enabled).toBe(false);
  });

  it('keeps OrbitControls enabled when not picking', () => {
    mockPickMode = null;
    render(<Viewer3D />);
    expect(lastOrbitProps?.enabled).toBe(true);
  });

  it('enables damping and ground-plane panning', () => {
    render(<Viewer3D />);
    expect(lastOrbitProps?.enableDamping).toBe(true);
    expect(lastOrbitProps?.screenSpacePanning).toBe(false);
  });

  it('clamps zoom distance', () => {
    render(<Viewer3D />);
    expect(lastOrbitProps?.minDistance).toBe(1);
    expect(lastOrbitProps?.maxDistance).toBe(500);
  });

  it('renders PathPointLayer and MapPointMarkers when point visibility is on', () => {
    render(<Viewer3D />);
    expect(pathPointRendered).toBe(true);
    expect(mapPointsRendered).toBe(true);
    expect(screen.getByTestId('path-point-layer')).toBeInTheDocument();
    expect(screen.getByTestId('map-point-markers')).toBeInTheDocument();
  });

  it('hides PathPointLayer and MapPointMarkers when point visibility is off', () => {
    mockVisibility = { ...mockVisibility, point: false };
    render(<Viewer3D />);
    expect(pathPointRendered).toBe(false);
    expect(mapPointsRendered).toBe(false);
  });
});
