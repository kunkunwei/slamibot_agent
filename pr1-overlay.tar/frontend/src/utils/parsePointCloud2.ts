interface Field { name: string; offset: number; datatype: number; count: number; }
export interface Pc2Msg {
  data: string | Uint8Array;
  fields: Field[];
  point_step: number;
  width: number;
  height: number;
  is_bigendian: boolean;
}

export function parsePointCloud2(msg: Pc2Msg, maxPoints = 100_000): Float32Array {
  if (!msg || !Array.isArray(msg.fields)) {
    return new Float32Array(0);
  }
  const { fields, point_step, width, height, is_bigendian } = msg;
  if (!point_step || !width || height == null) return new Float32Array(0);

  let raw: ArrayBuffer;
  if (msg.data instanceof Uint8Array) {
    // CBOR mode: data is raw bytes, no base64 decode needed
    raw = msg.data.buffer.slice(msg.data.byteOffset, msg.data.byteOffset + msg.data.byteLength) as ArrayBuffer;
  } else if (typeof msg.data === 'string') {
    // JSON mode: base64 decode
    try {
      const decoded = atob(msg.data);
      const buf = new Uint8Array(decoded.length);
      for (let i = 0; i < decoded.length; i++) buf[i] = decoded.charCodeAt(i);
      raw = buf.buffer;
    } catch {
      return new Float32Array(0);
    }
  } else {
    return new Float32Array(0);
  }
  const xf = fields.find((f) => f.name === 'x');
  const yf = fields.find((f) => f.name === 'y');
  const zf = fields.find((f) => f.name === 'z');
  if (!xf || !yf || !zf) return new Float32Array(0);
  const totalPoints = width * height;
  const step = Math.max(1, Math.ceil(totalPoints / maxPoints));
  const result: number[] = [];
  const view = new DataView(raw);
  const le = !is_bigendian;
  for (let i = 0; i < totalPoints; i += step) {
    const base = i * point_step;
    const x = view.getFloat32(base + xf.offset, le);
    const y = view.getFloat32(base + yf.offset, le);
    const z = view.getFloat32(base + zf.offset, le);
    if (!isFinite(x) || !isFinite(y) || !isFinite(z)) continue;
    result.push(x, y, z);
  }
  return new Float32Array(result);
}
